package prod;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import bus.*; 


public class FortisBankSystem {
	public static void main(String[] args) throws IOException, ClassNotFoundException, ParseException
	{
		BankOperations newBankSystem = new BankOperations();
		FileHandler file = new FileHandler();
		Vector<Client> listCustomers = new Vector<Client>();
		Vector<Account> listAccounts = new Vector<Account>();
		Scanner sc = new Scanner(System.in);
		//Writing in file the Clients Test
		//file.WriteToFileClients(new TestClassWithClientsInfo().listClientsTest());
		
		//Read from file the list of Clients
		listCustomers = file.ReadFromFileClients();
		
		
		//Test Add a new Client
		Client logClient = new Client(new Client().getNewUserCode(listCustomers),"Juan","Perez");
		Account newAcct1 = new Account(new Account().getNewAccountNumber(listAccounts),logClient,1234,new Date(),TypeAccount.Checking,4500.57, Status.Open);
		Account newAcct2 = new Account(new Account().getNewAccountNumber(listAccounts),logClient,6789,new Date(),TypeAccount.Saving,800.76, Status.Open);
		logClient.addAccount(newAcct1);
		logClient.addAccount(newAcct2);
		listCustomers.add(logClient);
		
		
		while (true) {
			System.out.println( "\n\t\t**************************************************");
			System.out.println( "\t\t\t FORTIS BANK MANAGEMENT SYSTEM");
			System.out.println( "\t\t**************************************************");
			
			//Stay in the login prompt until successful login
			
			newBankSystem.loginUser(listCustomers,sc);
			new Client().printUserPswd(listCustomers);
			logClient = newBankSystem.mainMenuPrompt(listCustomers, sc);
			
			//Stay inMain Menu until user quits
			//newBankSystem.printUserMenu(logClient,sc);
			
		}
	}
	
}