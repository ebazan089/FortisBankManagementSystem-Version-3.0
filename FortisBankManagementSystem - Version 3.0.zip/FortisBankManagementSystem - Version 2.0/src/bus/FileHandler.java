package bus;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;

public class FileHandler {

	public void WriteToFileClients(Vector<Client> myCustomersfromConsole) throws IOException
	{
		//WRITE TO BINARY FILE
		FileOutputStream fos = new FileOutputStream("src/data/myClients.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(myCustomersfromConsole);
		fos.close();
		oos.close();
	}
	
	@SuppressWarnings("unchecked")
	public Vector<Client> ReadFromFileClients() throws IOException, ClassNotFoundException
	{
		//READ FROM BINARY FILE
		Vector<Client> myCustomersfromFile = new Vector<Client>();
		FileInputStream fis = new FileInputStream("src/data/myClients.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		myCustomersfromFile = (Vector<Client>) ois.readObject();
		fis.close();
		ois.close();
		return myCustomersfromFile;
	}
	
	
	
}
