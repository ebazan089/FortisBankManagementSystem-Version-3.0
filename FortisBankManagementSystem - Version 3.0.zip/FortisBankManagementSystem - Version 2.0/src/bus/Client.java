package bus;
import java.util.*;
import java.io.Serializable;

public class Client implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String code;
	private String fn;
	private String ln;
	private Vector<Account> listAcct;
	
	public Client() {
		super();
		// TODO Auto-generated constructor stub
		this.listAcct = new Vector<Account>();
	}

	public Client(String code, String fn, String ln) {
		super();
		this.code = code;
		this.fn = fn;
		this.ln = ln;
		this.listAcct = new Vector<Account>();
	}
	
	public String getNewUserCode(Vector<Client> list){
		String code ="";
		Random rng = new Random();
		int length = 6;
		boolean nonUnique = false;
		do {
			code = "";
			for(int c= 0; c < length; c++)
			{
				code +=((Integer)rng.nextInt(10)).toString();
			}
			nonUnique = false;
			for(Client c: list)
			{
				if(code.compareTo(c.getCode())==0)
				{
					nonUnique = true;
					break;
				}
			}
		}while(nonUnique);
		return code;
	}
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getFn() {
		return fn;
	}

	public void setFn(String fn) {
		this.fn = fn;
	}

	public String getLn() {
		return ln;
	}

	public void setLn(String ln) {
		this.ln = ln;
	}

	public Vector<Account> getListAccount() {
		return listAcct;
	}

	public void setListcAccount(Vector<Account> cAccount) {
		this.listAcct = cAccount;
	}

	@Override
	public String toString() {
		return "\n\nCustomer Code: " + code + "\nFirst Name: " + fn + "\nLast Name: " + ln + "\nAccounts:" + listAcct;
	}
	
	public void addAccount(Account a) {
		this.listAcct.add(a);
	}
	
	public Client clientLogin(String userID, String pin, Vector<Client> list)
	{
		for(Client c: list)
		{
			if(c.getCode().compareTo(userID) == 0 && c.validatePin(pin,c.getListAccount())) {
				return c;
			}
		}
		return null;
	}
	
	//Show all the clients which are in the file
	public void printUserPswd(Vector<Client> list) {
		System.out.println( "\n\t\t\t***** CLIENTS ON FILE FOR TEST *****");
		for(Client a: list)
		{
			System.out.println("\n\tUserID: " + a.getCode() + printAllAccounts(a));
		}
	}
	
	public String printAllAccounts(Client a) {
		String acct="";
		int i=1;
		for(Account c: a.getListAccount())
		{
			acct = acct + "; Account #" + i + ": " + c.getAccountNumber() +" with PIN " + c.getPin();
			i++;
		}
		return acct;
	}
	
	public boolean validatePin(String pin, Vector<Account> list) {
		for(int i=0; i < list.size(); i++)
		{
			if(Integer.toString(list.get(i).getPin()).compareTo(pin) == 0) {
				return true;
			}
		}
		return false;
	}
	
	public void printAccountsSummary() {
		double balance;
		System.out.printf("\n\t\t%s %s's Accounts Summary: \n", this.fn, this.ln);
		System.out.println("\t\t---------------------------------------------------------------");
		System.out.println("\t\t  No. | TYPE_ACCOUNT | ACCOUNT_NUMBER |   BALANCE   /  STATUS");
		System.out.println("\t\t---------------------------------------------------------------");
		for(int i=0; i < this.listAcct.size(); i++)
		{
			balance = this.getListAccount().get(i).getBalance();
			if(balance >= 0)
			{
				if(i<10)
				{
					System.out.printf("\t\t  00%d  \t  %s    \t   %s      \t $%.2f   / %s\n",i+1, this.getListAccount().get(i).getTypeAccount().toString(), this.getListAccount().get(i).getAccountNumber(), balance, this.getListAccount().get(i).getaStatus());
				}else {
					System.out.printf("\t\t  0%d  \t  %s    \t   %s      \t $%.2f   / %s\n",i+1, this.getListAccount().get(i).getTypeAccount().toString(), this.getListAccount().get(i).getAccountNumber(), balance, this.getListAccount().get(i).getaStatus());
				}
			}
			else
			{
				if(i<10)
				{
					System.out.printf("\t\t  00%d  \t  %s    \t   %s      \t $(%.2f)   \t%s\n",i+1, this.getListAccount().get(i).getTypeAccount().toString(), this.getListAccount().get(i).getAccountNumber(), balance, this.getListAccount().get(i).getaStatus());
				}else {
					System.out.printf("\t\t  0%d  \t  %s    \t   %s      \t $(%.2f)   \t%s\n",i+1, this.getListAccount().get(i).getTypeAccount().toString(), this.getListAccount().get(i).getAccountNumber(), balance, this.getListAccount().get(i).getaStatus());					}
			}
		}
	}
	
	public int numAccounts() {
		return this.listAcct.size();
	}

	public void printAcctTransHistory(int index)
	{
		this.listAcct.get(index).printTransHistory();
	}
	
	public double getAcctBalance(int acctIdx) {
		return this.listAcct.get(acctIdx).getBalance();
	}
	
	public void addAcctTransaction(int acctIdx, double amount, String description, TypeTransaction type)
	{
		this.listAcct.get(acctIdx).addTransaction(amount,description,type);
	}

}
