package bus;
import bus.Client;

import java.util.Scanner;
import java.util.Vector;

public interface IOperations {
	public Client mainMenuPrompt(Vector<Client> list, Scanner sc);
	public void showTransHistory(Client c, Scanner sc);
	public void transferFunds(Client c, Scanner sc);	
	public void withdrawFunds(Client c, Scanner sc);
	public void depositFunds(Client c, Scanner sc);
}
