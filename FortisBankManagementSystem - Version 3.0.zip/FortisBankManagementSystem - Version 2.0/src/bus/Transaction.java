package bus;
import java.util.Date;
import java.util.Random;
import java.util.Vector;
import java.io.Serializable;
import java.text.SimpleDateFormat;

public class Transaction implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String numberT;
	private String description;
	private Date timestamp;
	private double amount;
	private TypeTransaction typeT;
	
	//implement interface deposit, withdraw, payment; interface operation
	
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Transaction(String numTransaction, String description, Date dateT, double amount, TypeTransaction typeT) {
		super();
		this.numberT = numTransaction;
		this.description = description;
		this.timestamp = dateT;
		this.amount = amount;
		this.typeT = typeT;
	}

	public String getNewTransactionCode(Vector<Transaction> list){
		String code ="";
		Random rng = new Random();
		int length = 6;
		boolean nonUnique = false;
		do {
			code = "";
			for(int c= 0; c < length; c++)
			{
				code +=((Integer)rng.nextInt(10)).toString();
			}
			nonUnique = false;
			for(Transaction t: list)
			{
				if(code.compareTo(t.getNumberT()) == 0)
				{
					nonUnique = true;
					break;
				}
			}
		}while(nonUnique);
		return code;
	}
	
	public String getNumberT() {
		return numberT;
	}

	public void setNumberT(String numberT) {
		this.numberT = numberT;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public TypeTransaction getTypeT() {
		return typeT;
	}

	public void setTypeT(TypeTransaction typeT) {
		this.typeT = typeT;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public String toString() {
		return "\n\t   Transaction Number:" + numberT + " - " + description +" - " + timestamp + " - " + typeT + " - $" + amount + " (" + typeT + ")";
	}

	public String getSummaryLine()
	{
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy/MM/dd");
		if(this.amount >=0) {
			return String.format("\t\t     %s\t      %s \t%s   \t$%.02f / %s", this.numberT, dateFormatter.format(this.timestamp),this.description,this.amount,this.typeT.toString());
			//return String.format("\n\t\t%s : $%.02f : %s", dateFormatter.format(this.timestamp),this.amount, this.description);
		} else {
			return String.format("\t\t     %s\t      %s \t%s   \t$(%.02f) / %s", this.numberT, dateFormatter.format(this.timestamp),this.description,this.amount,this.typeT.toString());
			//return String.format("\n\t\t%s : $(%.02f) : %s", dateFormatter.format(this.timestamp),this.amount, this.description);
		}
		
		
	}
	
}
