package bus;

public enum Status {
	Open, Close;

}
