package bus;

public enum TypeAccount {
	Checking, Saving, Credit, Currency;
}
