package bus;
import java.util.*;

public class FortisBank {
	private String name;
	private Vector<Client> listClients;
	private Vector<Account> listAccounts;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Vector<Client> getListClients() {
		return listClients;
	}
	public void setListClients(Vector<Client> listClients) {
		this.listClients = listClients;
	}
	public Vector<Account> getListAccounts() {
		return listAccounts;
	}
	public void setListAccounts(Vector<Account> listAccounts) {
		this.listAccounts = listAccounts;
	}
	
	
	
}
