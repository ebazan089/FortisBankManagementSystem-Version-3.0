package bus;
import java.util.*;
import java.io.Serializable;

public class Account extends Transaction implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Client holder;
	private String accountNumber;
	private Date openDate;
	private int pin;
	private TypeAccount typeAccount;
	private double balance;
	private Status aStatus;
	private Vector<Transaction> listTrans;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
		this.listTrans = new Vector<Transaction>();
	}
	
	public Account(String acctNumber, Client holder, int pin, Date openDate, TypeAccount typeAccount, double balance,
			Status aStatus) {
		super();
		this.accountNumber = acctNumber;
		this.holder = holder;
		//this.accountNumber = getNewAccountNumber();
		this.pin = pin;
		this.openDate = openDate;
		this.typeAccount = typeAccount;
		this.balance = balance;
		this.aStatus = aStatus;
		this.listTrans = new Vector<Transaction>();
		//holder.getListAccount().add(this);
	}

	public String getNewAccountNumber(Vector<Account> list){
		String code ="";
		Random rng = new Random();
		int length = 6;
		boolean nonUnique = false;
		do {
			code = "";
			for(int c= 0; c < length; c++)
			{
				code +=((Integer)rng.nextInt(10)).toString();
			}
			nonUnique = false;
			for(Account c: list)
			{
				if(code.compareTo(c.getAccountNumber())==0)
				{
					nonUnique = true;
					break;
				}
			}
		}while(nonUnique);
		return code;
	}
	
	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public Client getHolder() {
		return holder;
	}

	public void setHolder(Client holder) {
		this.holder = holder;
	}

	public String getAccountNumber() {
		return accountNumber;
	}
	
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Date getOpenDate() {
		return openDate;
	}
	
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	
	public TypeAccount getTypeAccount() {
		return typeAccount;
	}

	public void setTypeAccount(TypeAccount typeAccount) {
		this.typeAccount = typeAccount;
	}

	public double getBalanceFirst() {
		return balance;
	}
	
	public double getBalance() {
		double balance = this.balance;
		for (Transaction t: this.listTrans) {
			balance += t.getAmount();
		}
		this.balance = balance;
		return balance;
	}

	
	public void getUpdatedBalance(int acctIdx) {
		double balance = this.balance;
		for (Transaction t: this.listTrans) {
			balance += t.getAmount();
		}
		this.balance = balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Status getaStatus() {
		return aStatus;
	}

	public void setaStatus(Status aStatus) {
		this.aStatus = aStatus;
	}

	public Vector<Transaction> getListTrans() {
		return listTrans;
	}

	public void setListTrans(Vector<Transaction> listT) {
		this.listTrans = listT;
	}

	@Override
	public String toString() {
		return "\n- AccountNumber: " + accountNumber + "\n- OpenDate: " + openDate + "\n- Type Account: "
				+ typeAccount + "\n- Balance: $" + balance + "\n- Status: " + aStatus + "\n- List of Transactions:" + listTrans;
	}
	
	public void printTransHistory() {
		System.out.printf("\n\t\t\t****** Transaction History for Account No. %s ******\n", this.accountNumber);
		if(this.listTrans.size() == 0)
			System.out.println("\n\t\t\tThere is no transaction in this account for this month...!");
		else {
			System.out.println("\t\t---------------------------------------------------------------------------------------------");
			System.out.println("\t\t  TRANSACTION No. |      DATE      |          DESCRIPTION          |      AMOUNT / TYPE    ");
			System.out.println("\t\t---------------------------------------------------------------------------------------------");
			for(int t = this.listTrans.size()-1; t>=0; t--) {
			
				System.out.printf(this.listTrans.get(t).getSummaryLine());
				System.out.println();
			}
		}
	}
	
	public void addTransaction(double amount, String memo, TypeTransaction type) {
		Transaction newTrans = new Transaction(this.getNewTransactionCode(this.listTrans),memo,new Date(), amount, type);
		this.listTrans.add(newTrans);
		Transaction fees = CheckingAccount.extraChargesPerTransactions(this.listTrans);
		if (fees != null)
		{
			this.listTrans.add(fees);
		}
		//if(this.typeAccount == TypeAccount.Chequing)
		//	CheckingAccount.extraChargesPerTransactions(this.listTrans);
	}

}
