package bus;
import java.util.Date;
import java.util.Calendar;
import java.util.Vector;
import java.io.Serializable;

public class CheckingAccount extends Account implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static int limit = 4;
	static double fees = 0.35;
	
	public static Transaction extraChargesPerTransactions(Vector <Transaction> list) {
		Date dateEnd = new Date();
		for(Transaction t: list)
		{
			dateEnd = endDate(t.getTimestamp());
			if(t.getTimestamp().before(dateEnd))
			{
				if(transDone(list))
				{
					Transaction feesTrans = new Transaction(new Transaction().getNewTransactionCode(list), "Extra Fees\t\t", t.getTimestamp(),fees,TypeTransaction.Fees);
					return feesTrans;
				}
			}
		}
		return null;
	}
	
	public static boolean transDone(Vector<Transaction> list)
	{
		Date dateEnd = new Date();
		int count = 0;
		for(Transaction t: list)
		{
			dateEnd = endDate(t.getTimestamp());
			if(t.getTypeT() == TypeTransaction.Withdraw) { count++;}
			if(t.getTimestamp().before(dateEnd))
			{
				if(count > limit )
					return true;
			}
		}
		return false;
	}

	public static Date endDate(Date startDate) {
        Calendar calendar = Calendar.getInstance();  
        calendar.setTime(startDate);  

        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);  

        Date endDate = calendar.getTime();  

        return endDate;
	}

}
