package bus;

public enum TypeTransaction {
	Deposit, Withdraw, Payment, Transfer, Fees;
}
