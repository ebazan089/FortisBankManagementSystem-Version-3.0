package bus;

import java.io.IOException;
import java.util.Date;
import java.util.Objects;
import java.util.Scanner;
import java.util.Vector;

public class BankOperations implements IOperations{

	public void loginUser(Vector<Client> list, Scanner sc) throws IOException
	{
		String user, psw;
		do {
			System.out.print( "\n\n\t Enter USERNAME: ");
			user = sc.nextLine();
			System.out.print( "\n\t Enter PASSWORD: ");
			psw = sc.nextLine();
			if(!Objects.equals(user, psw))
			{
				System.out.println("\n\t\tIncorrect Username/Password combination. Please try again!");
			}
		}while(!Objects.equals(user, psw));
		this.menuActions(list, sc);
	}
	
	public void menuActions(Vector<Client> list, Scanner sc) throws IOException {
		int choice;
		String opt;
		FileHandler file = new FileHandler();
		do {
			System.out.println("\n\n\t  1) Create a new Client");
			System.out.println("\n\t  2) Transaction in a Account");
			System.out.println("\n\t  3) Quit");
			System.out.println("\n\t\t Enter choice: ");
			choice = sc.nextInt();
			if(choice<1 || choice >3)
			{
				System.out.println("\n\n Invalid choice. Please choose 1-5");
			}
		}while(choice <1 || choice > 3);
		
		switch(choice) {
			case 1:
				createNewClient(list,sc);
				break;
			case 2:
				new Client().printUserPswd(list);
				Client logClient = this.mainMenuPrompt(list, sc);
				this.printUserMenu(logClient,sc);
				break;
			case 3:
				do {
					System.out.println("\n\n\t  Do you want to QUIT without saving the changes (YES/NO)? ");
					opt = sc.next();
					if(!Objects.equals(opt, "YES") && !Objects.equals(opt, "NO"))
					{
						System.out.println("\n\n Invalid choice. Please choose YES or NO");
					}
				}while(!Objects.equals(opt, "YES") && !Objects.equals(opt, "NO"));
				if(Objects.equals(opt, "YES"))
				{
					file.WriteToFileClients(list);
					System.out.println("\n\n***** All Clients were SAVED...!!! *****");
				}
				sc.nextLine();
				this.loginUser(list,sc);
				break;
		}
		if(choice !=5) {
			this.menuActions(list, sc);
		}
	}
	
	public void createNewClient(Vector<Client> list, Scanner sc) {
		Client newClient = new Client();
		String code, fn, ln;
		code = new Client().getNewUserCode(list);
		System.out.print( "\n\n\t New Client ID: " + code );
		System.out.print( "\n\n\t Enter Client First Name: ");
		fn = sc.nextLine();
		//sc.nextLine();
		System.out.print( "\n\t Enter Client Last Name: ");
		ln = sc.nextLine();
		newClient.setCode(code);
		newClient.setFn(fn);
		newClient.setLn(ln);
		createNewAccount(newClient,sc);
		list.add(newClient);

	}
	
	public void createNewAccount(Client newClient, Scanner sc) {
		int pin, choice, count =1;
		Account newAccount = new Account();
		
		do {
			
			newAccount.setHolder(newClient);
			newAccount.setAccountNumber(new Account().getNewAccountNumber(newClient.getListAccount()));
			newAccount.setOpenDate(new Date());
			System.out.printf("\n\n\tAccount #%d : %s\n", count,newAccount.getAccountNumber());
			System.out.print( "\n\t Enter PIN: ");
			pin = sc.nextInt();
			newAccount.setPin(pin);
			
			do {
				System.out.print( "\n\t What type of Account do you want to open? ");
				System.out.println("\n\n\t\t  1) Checking Account");
				System.out.println("\t\t  2) Saving Account");
				System.out.println("\t\t  3) Credit Account");
				System.out.println("\t\t  4) Currency Account");
				System.out.print("\t\t Enter choice: ");
				choice = sc.nextInt();
				if(choice<1 || choice >4)
				{
					System.out.println("\n\n Invalid choice. Please choose 1-5");
				}
			}while(choice <1 || choice > 4);
			
			switch(choice) {
			case 1:
				newAccount.setTypeAccount(TypeAccount.Checking);
				break;
			case 2:
				newAccount.setTypeAccount(TypeAccount.Saving);
				break;
			case 3:
				newAccount.setTypeAccount(TypeAccount.Credit);
				break;
			case 4:
				newAccount.setTypeAccount(TypeAccount.Currency);
				break;
			case 5:
				sc.nextLine();
				break;
			}
			newAccount.setBalance(0);
			newAccount.setaStatus(Status.Open);
			newClient.addAccount(newAccount);
			count++;
		}while(!checkMinimumOneCheckingAcct(newClient.getListAccount()));
		System.out.printf("\n\t***** Client #%s : %s %s was created with %d Account(s)...!!! *****", newClient.getCode(), newClient.getFn(), newClient.getLn(), newClient.getListAccount().size());
	}
	
	public boolean checkMinimumOneCheckingAcct(Vector<Account> list)
	{
		int countChecking = 0;
		for(Account a: list) 
		{
			if(Objects.equals(a.getTypeAccount(), TypeAccount.Checking))
				countChecking++;
				
		}
		if(countChecking >0)
			return true;
		else {
			System.out.println("\n\t You need to have at least ONE CHECKING ACCOUNT");
			return false;
		}
	}
	
	public Client mainMenuPrompt(Vector<Client> list, Scanner sc)
	{
		String userID;
		String pin;
		Client authClient;
		do {
			System.out.print( "\n\n\t Enter Client ID: ");
			userID = sc.nextLine();
			System.out.print( "\n\t Enter PIN: ");
			pin = sc.nextLine();
			authClient = new Client().clientLogin(userID, pin, list);
			if(authClient == null)
			{
				System.out.println("\n\t\tIncorrect Client ID/ PIN combination. Please try again!");
			}
		}while(authClient == null);
		authClient.printAccountsSummary();		
		return authClient;
	}
	
	public void printUserMenu(Client theClient, Scanner sc){
		int choice;
		do {
			System.out.printf("\n\tWelcome %s %s, what would you like to do?", theClient.getFn(), theClient.getLn());
			System.out.println("\n\n\t\t  1) Show Account Transaction History");
			System.out.println("\t\t  2) Withdraw");
			System.out.println("\t\t  3) Deposit");
			System.out.println("\t\t  4) Transfer");
			System.out.println("\t\t  5) Quit\n");
			System.out.print("\t\t Enter choice: ");
			choice = sc.nextInt();
			if(choice<1 || choice >5)
			{
				System.out.println("\n\n Invalid choice. Please choose 1-5");
			}
		}while(choice <1 || choice > 5);
		
		switch(choice) {
			case 1:
				this.showTransHistory(theClient,sc);
				break;
			case 2:
				this.withdrawFunds(theClient,sc);
				break;
			case 3:
				this.depositFunds(theClient,sc);
				break;
			case 4:
				this.transferFunds(theClient,sc);
				break;
			case 5:
				sc.nextLine();
				break;
		}
		if(choice !=5) {
			this.printUserMenu(theClient, sc);
		}
	}
	
	public void showTransHistory(Client c, Scanner sc){
		int optAcct;
		do {
			System.out.printf("\n\t\tEnter the number (1-%d) of the account whose transactions you want to see: ", c.numAccounts());
			optAcct = sc.nextInt()-1;
			if(optAcct < 0 || optAcct >= c.numAccounts())
			{
				System.out.println("Invalid account. Please try again.");
			}
		}while(optAcct < 0 || optAcct >= c.numAccounts());
		
		c.printAcctTransHistory(optAcct);
		
	}

	public void transferFunds(Client c, Scanner sc){
		int fromAcct;
		int toAcct;
		double amount;
		double acctBal;

		//Get the account to TRANSFER FROM
		do {
			System.out.printf("\n\tEnter the number (1-%d) of the account to transfer FROM: ",c.numAccounts());
			fromAcct = sc.nextInt()-1;
			if(fromAcct < 0 || fromAcct >= c.numAccounts())
			{
				System.out.println("\n\t\t\tInvalid account. Please try again.");
			}
		}while(fromAcct < 0 || fromAcct >= c.numAccounts());
		acctBal = c.getAcctBalance(fromAcct);
		
		//Get the account to TRANSFER TO
		do {
			System.out.printf("\n\tEnter the number (1-%d) of the account ro transfer TO: ",c.numAccounts());
			toAcct = sc.nextInt()-1;
			if(toAcct < 0 || toAcct >= c.numAccounts())
			{
				System.out.println("\n\t\t\tInvalid account. Please try again.");
			}
		}while(toAcct < 0 || toAcct >= c.numAccounts());
		
		//Get the AMOUNT to TRANSFER
		do {
			System.out.printf("\n\tEnter the amount to transfer (max $%.02f): $  ", acctBal);
			amount = sc.nextDouble();
			if(amount < 0)
			{
				System.out.println("\n\t\tAmount must be greater than zero.");
			}else if (amount > acctBal) {
				System.out.printf("\n\t\tAmount must not be greater than balance of $%.02f.",acctBal);
			}
		}while(amount < 0 || amount > acctBal);
		
		//Update Balance
		c.getListAccount().get(fromAcct).getUpdatedBalance(fromAcct);
		c.getListAccount().get(toAcct).getUpdatedBalance(toAcct);
		
		//Finally, do the transfer
		c.addAcctTransaction(fromAcct, -1*amount, String.format("Transfer TO account %s", c.getListAccount().get(toAcct).getAccountNumber()),TypeTransaction.Transfer);
		c.addAcctTransaction(toAcct, amount, String.format("Transfer FROM account %s", c.getListAccount().get(fromAcct).getAccountNumber()),TypeTransaction.Transfer);
		
	}

	public void withdrawFunds(Client c, Scanner sc)
	{
		int fromAcct;
		double amount;
		double acctBal;
		//Get the account to WITHDRAW 
		do {
			System.out.printf("\n\tEnter the number (1-%d) of the account to WITHDRAW from: ",c.numAccounts());
			fromAcct = sc.nextInt()-1;
			if(fromAcct < 0 || fromAcct >= c.numAccounts())
			{
				System.out.println("\n\t\t\tInvalid account. Please try again.");
			}
		}while(fromAcct < 0 || fromAcct >= c.numAccounts());
		acctBal = c.getAcctBalance(fromAcct);
		
		//Get the AMOUNT to WITHDRAW
		do {
			System.out.printf("\n\tEnter the amount to WITHDRAW (max $%.02f): $  ", acctBal);
			amount = sc.nextDouble();
			if(amount < 0)
			{
				System.out.println("\n\t\t\tAmount must be greater than zero.");
			}else if (amount > acctBal) {
				System.out.printf("\n\t\t\tAmount must not be greater than balance of $%.02f.",acctBal);
			}
		}while((amount < 0 || amount > acctBal) && amount > 500);
		sc.nextLine();
		
		//Update Balance
		c.getListAccount().get(fromAcct).getUpdatedBalance(fromAcct);
		//Do the WITHDRAW
		c.addAcctTransaction(fromAcct, -1*amount, String.format("Withdraw by %s %s",c.getFn(),c.getLn()),TypeTransaction.Withdraw);
	}
	
	public void depositFunds(Client c, Scanner sc)
	{
		int toAcct;
		double amount;

		//Get the account to DEPOSIT 
		do {
			System.out.printf("\n\tEnter the number (1-%d) of the account to DEPOSIT: ",c.numAccounts());
			toAcct = sc.nextInt()-1;
			if(toAcct < 0 || toAcct >= c.numAccounts())
			{
				System.out.println("\n\t\t\tInvalid account. Please try again.");
			}
		}while(toAcct < 0 || toAcct >= c.numAccounts());
		
		//Get the AMOUNT to DEPOSIT
		do {
			System.out.println("\n\tEnter the amount to DEPOSIT (min $1.00): $  ");
			amount = sc.nextDouble();
			if(amount < 1)
			{
				System.out.println("\n\t\t\tAmount must be greater than zero.");
			}
		}while(amount < 1 );
		sc.nextLine();

		//Update Balance
		c.getListAccount().get(toAcct).getUpdatedBalance(toAcct);		
		
		//Do the DEPOSIT
		c.addAcctTransaction(toAcct, amount, String.format("Deposit by %s %s",c.getFn(),c.getLn()),TypeTransaction.Deposit);
	}

}
