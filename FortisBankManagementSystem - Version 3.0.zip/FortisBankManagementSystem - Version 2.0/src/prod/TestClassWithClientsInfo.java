package prod;
import java.util.Vector;

import bus.Account;
import bus.Client;
import bus.Status;
import bus.Transaction;
import bus.TypeAccount;
import bus.TypeTransaction;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TestClassWithClientsInfo {

	public Vector<Client> listClientsTest() throws ParseException
	{
		Vector<Client> listCustomers = new Vector<Client>();
		Vector<Account> listAccounts1 = new Vector<Account>();
		Vector<Account> listAccounts2 = new Vector<Account>();
		Vector<Transaction> listTrans1 = new Vector<Transaction>();
		Vector<Transaction> listTrans2 = new Vector<Transaction>();
		Vector<Transaction> listTrans3 = new Vector<Transaction>();
		Vector<Transaction> listTrans4 = new Vector<Transaction>();
		Vector<Transaction> listTrans5 = new Vector<Transaction>();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		
		//NEW CLIENTS
		Client c1 = new Client(new Client().getNewUserCode(listCustomers),"Michelle","Smith");
		Client c2 = new Client(new Client().getNewUserCode(listCustomers),"Karl","Brown");
		
		
		//ACCOUNTS FOR EACH ACCOUNT
		Account c1a1 = new Account(new Account().getNewAccountNumber(listAccounts1),c1,1111,sdf.parse("2000/11/20"),TypeAccount.Checking,10200.33, Status.Open);
		Account c1a2 = new Account(new Account().getNewAccountNumber(listAccounts1),c1,2222,sdf.parse("2003/09/21"),TypeAccount.Saving,1450.76, Status.Open);
		
		Account c2a1 = new Account(new Account().getNewAccountNumber(listAccounts2),c2,3333,sdf.parse("2003/05/08"),TypeAccount.Checking,4566.50, Status.Open);
		Account c2a2 = new Account(new Account().getNewAccountNumber(listAccounts2),c2,4444,sdf.parse("2009/01/12"),TypeAccount.Saving,5020.57, Status.Open);
		Account c2a3 = new Account(new Account().getNewAccountNumber(listAccounts2),c2,5555,sdf.parse("2003/10/19"),TypeAccount.Credit,254.33, Status.Open);
		
		//Transaction Client 1 - Checking
		Transaction t1a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans1),"Rogers Payment",sdf.parse("2018/07/01"),1456.56,TypeTransaction.Withdraw);
		Transaction t2a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans1),"Hydro July ",sdf.parse("2018/07/07"),27.50,TypeTransaction.Withdraw);
		Transaction t3a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans1),"Rent July",sdf.parse("2018/07/12"),550.00,TypeTransaction.Withdraw);
		Transaction t4a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans1),"Mobile Cheque 2010",sdf.parse("2018/07/15"),1456.56,TypeTransaction.Withdraw);
		Transaction t5a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans1),"Apple Store",sdf.parse("2018/07/22"),550.32,TypeTransaction.Withdraw);
				
		//Transaction Client 1 - Saving
		Transaction t6a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans2),"Payroll Deposit STM",sdf.parse("2018/09/12"),2500.55,TypeTransaction.Deposit);
		Transaction t7a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans2),"Mobile Cheque - 5066",sdf.parse("2018/09/18"),125.00,TypeTransaction.Deposit);
		Transaction t8a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans2),"Virgin Mobile",sdf.parse("2018/09/24"),56.86,TypeTransaction.Payment);
		Transaction t9a1 = new Transaction(new Transaction().getNewTransactionCode(listTrans2),"Rent October",sdf.parse("2018/10/03"),450.00,TypeTransaction.Payment);
				
		//Transaction Client 2 - Checking
		Transaction t1a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans3),"Payroll Deposit IKEA",sdf.parse("2018/08/04"),643.25,TypeTransaction.Deposit);
		Transaction t2a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans3),"Payroll Deposit Structube",sdf.parse("2018/08/16"),250.00,TypeTransaction.Deposit);
		Transaction t3a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans3),"Bank National Ontario",sdf.parse("2018/09/22"),75.00,TypeTransaction.Withdraw);
		Transaction t4a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans3),"Bank National St. Hubert",sdf.parse("2018/09/25"),20.00,TypeTransaction.Payment);

		//Transaction Client 2 - Saving
		Transaction t5a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans4),"Payroll Deposit Hydro",sdf.parse("2018/10/05"),890.45,TypeTransaction.Deposit);
		Transaction t6a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans4),"Cheque - 9876",sdf.parse("2018/10/05"),250.00,TypeTransaction.Withdraw);
		Transaction t7a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans4),"RBC Sherbrooke",sdf.parse("2018/10/06"),75.00,TypeTransaction.Withdraw);
		Transaction t8a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans4),"RBC Mont-Royal",sdf.parse("2018/10/08"),100.00,TypeTransaction.Withdraw);
		
		//Transaction Client 2 - Credit
		Transaction t9a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans5),"Apple Store",sdf.parse("2018/10/06"),1456.56,TypeTransaction.Payment);
		Transaction t10a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans5),"Metro",sdf.parse("2018/10/06"),85.34,TypeTransaction.Payment);
		Transaction t11a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans5),"Pharmacy",sdf.parse("2018/10/06"),123.45,TypeTransaction.Payment);
		Transaction t12a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans5),"Cineplex",sdf.parse("2018/10/06"),33.45,TypeTransaction.Payment);
		Transaction t13a2 = new Transaction(new Transaction().getNewTransactionCode(listTrans5),"La Ronde",sdf.parse("2018/10/06"),155.92,TypeTransaction.Payment);
		
		//Adding accounts in clients
		c1.addAccount(c1a1);
		c1.addAccount(c1a2);
	
		c2.addAccount(c2a1);
		c2.addAccount(c2a2);
		c2.addAccount(c2a3);
		
		//Adding transactions
		c1.getListAccount().get(0).getListTrans().add(t1a1);
		c1.getListAccount().get(0).getListTrans().add(t2a1);
		c1.getListAccount().get(0).getListTrans().add(t3a1);
		c1.getListAccount().get(0).getListTrans().add(t4a1);
		c1.getListAccount().get(0).getListTrans().add(t5a1);
		c1.getListAccount().get(1).getListTrans().add(t6a1);
		c1.getListAccount().get(1).getListTrans().add(t7a1);
		c1.getListAccount().get(1).getListTrans().add(t8a1);
		c1.getListAccount().get(1).getListTrans().add(t9a1);
		
		c2.getListAccount().get(0).getListTrans().add(t1a2);
		c2.getListAccount().get(0).getListTrans().add(t2a2);
		c2.getListAccount().get(0).getListTrans().add(t3a2);
		c2.getListAccount().get(0).getListTrans().add(t4a2);
		c2.getListAccount().get(1).getListTrans().add(t5a2);
		c2.getListAccount().get(1).getListTrans().add(t6a2);
		c2.getListAccount().get(1).getListTrans().add(t7a2);
		c2.getListAccount().get(1).getListTrans().add(t8a2);
		c2.getListAccount().get(2).getListTrans().add(t9a2);
		c2.getListAccount().get(2).getListTrans().add(t10a2);
		c2.getListAccount().get(2).getListTrans().add(t11a2);
		c2.getListAccount().get(2).getListTrans().add(t12a2);
		c2.getListAccount().get(2).getListTrans().add(t13a2);
		
		//Adding Clients
		listCustomers.add(c1);
		listCustomers.add(c2);
		
		return listCustomers;
	}
	
}
